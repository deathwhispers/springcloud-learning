package com.sunshine.consumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudConsumerApplicationTests {

    @Test
    void contextLoads() {
    }

}
