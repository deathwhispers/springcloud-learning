package com.sunshine.provider;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudProviderApplicationTests {

    @Test
    void contextLoads() {
    }

}
