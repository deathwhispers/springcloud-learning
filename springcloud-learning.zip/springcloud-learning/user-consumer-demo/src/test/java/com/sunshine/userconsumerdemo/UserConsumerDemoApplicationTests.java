package com.sunshine.userconsumerdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserConsumerDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
